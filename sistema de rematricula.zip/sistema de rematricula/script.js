// =====================================

// SISTEMA DE REMATRÍCULA ONLINE

// =====================================

let rematriculas = [];


// REALIZAR REMATRÍCULA

function realizarRematricula(aluno) {

    if (

        !aluno.nome ||

        !aluno.cpf ||

        !aluno.email ||

        !aluno.curso ||

        !aluno.periodo

    ) {

        return "Preencha todos os campos obrigatórios!";

    }

    if (aluno.confirmacao !== true) {

        return "Confirme seus dados antes de continuar!";

    }

    const novaRematricula = {

        numero: "REM-" + Date.now(),

        nome: aluno.nome,

        cpf: aluno.cpf,

        email: aluno.email,

        curso: aluno.curso,

        periodo: aluno.periodo,

        anoLetivo: 2027,

        data: new Date().toLocaleDateString("pt-BR"),

        status: "Aguardando análise"

    };

    rematriculas.push(novaRematricula);

    return novaRematricula;

}


// CONSULTAR REMATRÍCULA

function consultarRematricula(numero) {

    const resultado = rematriculas.find(

        r => r.numero === numero

    );

    if (!resultado) {

        return "Rematrícula não encontrada!";

    }

    return resultado;

}


// ATUALIZAR STATUS DA REMATRÍCULA

function atualizarRematricula(numero, novoStatus) {

    const rematricula = rematriculas.find(

        r => r.numero === numero

    );

    if (!rematricula) {

        return "Solicitação não encontrada!";

    }

    const statusPermitidos = [

        "Aguardando análise",

        "Aprovada",

        "Rejeitada"

    ];

    if (!statusPermitidos.includes(novoStatus)) {

        return "Status inválido!";

    }

    rematricula.status = novoStatus;

    return rematricula;

}


// LISTAR TODAS AS REMATRÍCULAS

function listarRematriculas() {

    return rematriculas;

}


// =====================================

// EXEMPLO DE UTILIZAÇÃO

// =====================================

const nova = realizarRematricula({

    nome: "João da Silva",

    cpf: "12345678900",

    email: "joao@email.com",

    curso: "Análise e Desenvolvimento de Sistemas",

    periodo: "2º período",

    confirmacao: true

});

console.log("Rematrícula criada:", nova);

console.log(

    "Consulta:",

    consultarRematricula(nova.numero)

);

console.log(

    "Atualização:",

    atualizarRematricula(nova.numero, "Aprovada")

);

console.log(

    "Todas as rematrículas:",

    listarRematriculas()

);
 